ECS 163
Project 2
Josephine Situ

Dataset: https://www.kaggle.com/miroslavsabo/young-people-survey
		Young People Survey

-----------------------------------
            COMPLETED:
-----------------------------------
Visualization 1: Overview
	A normalized stacked bar chart that compares the percentages of how much people like a certain genre of music. 
	The brighter the hue of blue, the more that a person likes a genre; the brighter the hue of red, the more that a person dislikes a genre; the white hue means that the person neither likes or dislikes that genre. 

-----------------------------------
              TO-DO:
-----------------------------------
Visualization 1:
	- fix the padding around the graph
	- fix the overlapping x-axis labels
	- fix the overlapping of the legend
	- add filtering to detailed views
		- Clicking on a bar (genre) -> changes the detailed views


Visualization 2: Detailed View
	Radar Chart
		Displays music genre recommendations of a selected genre
			- If someone likes this genre, what other genres do they bound to like?
			- If someone dislikes this genre, what other genres do they bound to dislike?
		Radar chart would display the averages of the total rating of other music genres of those who either like or dislike the genre
			- higher average ratings would have a higher amplitude on the radar chart
			- lower average ratings would have a lower amplitude on the radar chart
			- radar chart would have a range from 1 to 5
			- radar chart would have axes of the music genres excluding the selected music genre
			

Visualization 3: Detailed View	
	Possibly a Box and Whisker Plot
		Display range of demographics of the selected genre: Age, Number of siblings, gender, Highest education achieved, hometown type
