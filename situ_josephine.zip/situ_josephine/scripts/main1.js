// vis1.js

function BarChart(container, data, onUpdate) {

	console.log("BarChart");

	this.onUpdate = onUpdate;

    	// set margins of the graph
	var margin = {top: 10, right: 50, bottom: 20, left: 40};
	var width = (window.innerWidth * 0.5) - margin.left - margin.right;
	var height = (window.innerHeight * 0.8) - margin.top - margin.bottom;

	// create the svg canvas
	var svg = d3.select("#vis1")
		.append("svg")
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom);

	// define a group (to keep items clustered in respective groups)
	var g = svg.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var x = d3.scaleBand().rangeRound([0, width]).paddingInner(0.10).align(0.1);
	var y = d3.scaleLinear().rangeRound([height, 0]);
	var color = d3.scaleOrdinal().range(["#EC7063", "#F5B7B1", "#FDFEFE", "#AED6F1", "#5DADE2"]);
	
	var stack = d3.stack()
		.offset(d3.stackOffsetExpand);

    this.update = function(data) {

    	// var Genres = data.columns.slice(1);
    	// console.log(Genres);

    	// var AverageMap = {};

    	// console.log(data.columns[0]);
    	// console.log(data[0]);

    	console.log(data);

  //   	data.forEach(function(d, i, columns) {

  //   		// for (i = 1, j = 0, total = 0; i < columns.length; i++)
	 //    		// total += d[columns[i]] = +d[columns[i]];
	 //    		// d.frequency = total;

	 //    			// AverageMap[d[columns[i]] ]
	 //    		// };

		// var TotaledData = [];

		// Object.keys(AverageMap).forEach(function(key) {
		// 	TotaledData.push({
		// 		genre: key,
		// 		count: AverageMap[key]
		// 	});
		// });

		// console.log(TotaledData);

		x.domain(data.map(function(d) { return d.Genre; }));

		color.domain(data.columns.slice(1));

		var bars = g.selectAll(".bars")
			.data(stack.keys(data.columns.slice(1))(data))
			.enter().append("g")
			.attr("class", "bars")
			.attr("fill", function(d) { return color(d.key); });

		bars.selectAll("rect")
			.data(function(d) { return d; })
			.enter().append("rect")
			.attr("x", function(d) { return x(d.data.Genre); })
			.attr("y", function(d) { return y(d[1]); })
			.attr("height", function(d) { return y(d[0]) - y(d[1]); })
			.attr("width", x.bandwidth());

		g.append("g")
			.attr("class", "axis axis--x")
			.attr("transform", "translate(0," + height + ")")
			.call(d3.axisBottom(x));

		g.append("g")
			.attr("class", "axis axis--y")
			.call(d3.axisLeft(y).ticks(10, "%"));

		// create a legend
		var legend = bars.append("g")
			.attr("font-family", "sans-serif")
			.attr("font-size", 12)
			.attr("text-anchor", "end")
			.selectAll("g")
			.data(data.columns.slice(1).reverse())
			.enter().append("g")
			.attr("transform", function(d, i) {return "translate(0," + i * 20 + ")"; });

		// add color boxes to the legend
		legend.append("rect")
			.attr("x", width)
			.attr("width", 18)
			.attr("height", 18)
			.attr("fill", color);

		// add text to the legend
		legend.append("text")
			.attr("x", width - 5)
			.attr("y", 10)
			.attr("dy", "0.33em")
			.text(function(d) {return d;});

        // this.updatePositions = function(selection) {
        //     selection
        //         .attr('x', function(d) { return margin.left + x(d.key); })
        //         .attr('y', function(d) { return y(d.value); })
        //         .attr('width', x.bandwidth())
        //         .attr('height', function(d) { return chartHeight - y(d.value); })
        //         .attr('fill', function() { return 'steelblue'; });


        //     return selection;
        // }

        //updatePositions(enterBars);
        // this.updatePositions(g.selectAll('.bar'));

    }

    // do our initial update with our initial data
    this.update(data);
}