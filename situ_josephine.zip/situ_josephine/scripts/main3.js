// vis3.js

function TBD2(container, data, initialGenre) {

	console.log("vis3.js");

	// set margins of the graph
	var margin3 = {top: 20, right: 30, bottom: 10, left: 30};
	var width3 = (window.innerWidth * 0.4) - margin3.left - margin3.right;
	var height3 = (window.innerHeight * 0.4) - margin3.top - margin3.bottom;

	// create the svg canvas
	var svg3 = d3.select("#vis3")
		.append("svg")
		.attr("width", width3 + margin3.left + margin3.right)
		.attr("height", height3 + margin3.top + margin3.bottom);

	// define a group (to keep items clusted in respective groups)
	var g3 = svg3.append("g")
		.attr("transform", "translate(" + margin3.left + "," + margin3.top + ")");

}