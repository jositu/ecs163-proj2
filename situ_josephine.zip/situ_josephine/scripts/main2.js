// vis2.js

function RadarChart(container, data, initialGenre) {

	console.log("RadarChart");

	// set margins of the graph
	var margin = {top: 20, right: 30, bottom: 10, left: 30};
	var width = (window.innerWidth * 0.4) - margin.left - margin.right;
	var height = (window.innerHeight * 0.4) - margin.top - margin.bottom;

	// create the svg canvas
	var svg = d3.select("#vis2")
		.append("svg")
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom);

	var chartWidth = width - margin.left - margin.right;
	var chartHeight = height - margin.top - margin.bottom;

	var radius = Math.min(chartWidth, chartHeight) / 2;

	var color = d3.scaleOrdinal(d3.schemeSet1);

	var g = svg.append("g")
			.attr("transform", "translate(" + (width/2 + margin.left) + "," + (height/2 + margin.top) + ")");

	this.update = function(data, targetGenre){

		svg.selectAll("*").remove();

	var cfg = {
		w: width,
		h: height,
		margin: margin,
		maxValue: 0.5,
		levels: 5,
		color: color,
		maxValue: 0, 			
	 labelFactor: 1.25, 	
	 wrapWidth: 60, 		
	 opacityArea: 0.35, 	//The opacity of the area of the blob
	 dotRadius: 4, 			//The size of the colored circles of each blog
	 opacityCircles: 0.1, 	//The opacity of the circles of each blob
	 strokeWidth: 2		//The width of the stroke around each blob
	};


		// filter data into two categories
		// those who like the genre ( >3 )
		// those who don't like the genre ( <3 )
		var LikesData = [];
		var DislikesData = [];

		data.forEach(function(d) {
			if (3 < d[targetGenre]) LikesData.push(d);
			if (3 > d[targetGenre]) DislikesData.push(d);
		})

		console.log(LikesData);
		console.log(DislikesData);

		// var Genres = [];
		// data.forEach(function(d, column, index) {
		// 	// if (d[column] !== "Likes_Music" || d[column] !== "Slow_Fast") Genres.push(d);
		// 	console.log(d[1]);
		// })

		// console.log(Genres);

		console.log(LikesData[1]);
		var AverageLiked = FindAverage(LikesData);

		console.log("AverageLiked");
		console.log(AverageLiked);


		var testAverages = [
			[//likes
				{ "axis":"Dance_Disco_Funk", "value":2},
				{  "axis":"Folk", "value":5 },
				{ "axis":"Country", "value":4 },
				{ "axis":"Classical", "value":2 },
				{  "axis":"Musicals","value":3.4}
			]
			[//dislikes
				{ "axis":"Dance_Disco_Funk", "value":5},
				{  "axis":"Folk", "value":2 },
				{ "axis":"Country", "value":4 },
				{ "axis":"Classical", "value":2 },
				{  "axis":"Musicals","value":4}
			]			 
    	];
		

		// console.log(Genres);

		var axisGrid = g.append("g")
			.attr("class", "axisWrapper");
		axisGrid.selectAll(".levels")
	   .data(d3.range(0,5))
	   .enter()
		.append("circle")
		.attr("class", "gridCircle")
		.attr("r", function(d, i){return radius/cfg.levels*d;})
		.style("fill", "#FFFFFF")
		.style("stroke", "#FFFFFF")
		.style("fill-opacity", cfg.opacityCircles);
		// .style("filter" , "url(#glow)");

	// //Text indicating at what % each level is
	// axisGrid.selectAll(".axisLabel")
	//    .data(d3.range(1,(cfg.levels+1)).reverse())
	//    .enter().append("text")
	//    .attr("class", "axisLabel")
	//    .attr("x", 4)
	//    .attr("y", function(d){return -d*radius/cfg.levels;})
	//    .attr("dy", "0.4em")
	//    .style("font-size", "10px")
	//    .attr("fill", "#737373")
	//    .text(function(d,i) { return Format(maxValue * d/cfg.levels); });


	}

	this.update(data, initialGenre);
}

function FindAverage(d) {
	var temp = [];
	for (i = 1, total = 0; i < d.length; i++) {
		temp.total += 0;
	}
	return temp;
}