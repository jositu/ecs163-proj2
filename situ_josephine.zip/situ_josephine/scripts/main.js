// main.js
console.log("main.js");

// read in our CSV file
d3.csv("./data/counted.csv", function(data){ 
        // get all of our data into the requisite format first
        // console.log(datum);
    //     return {
    //         // "Likes_Music": +datum["Music"],
    //         // "Slow_Fast": +datum["Slow songs or fast songs"],
    //         // "Dance_Disco_Funk": +datum["Dance"],
    //         // "Folk": +datum["Folk"],
    //         // "Country": +datum["Country"],
    //         // "Classical": +datum["Classical music"],
    //         // "Musicals": +datum["Musical"],
    //         // "Pop": +datum["Pop"],
    //         // "Rock": +datum["Rock"],
    //         // "Metal_Hardrock": +datum["Metal or Hardrock"],
    //         // "Punk": +datum["Punk"],
    //         // "Hiphop_Rap": +datum["Hiphop, Rap"],
    //         // "Reggae_Ska": +datum["Reggae, Ska"],
    //         // "Swing_Jazz": +datum["Swing, Jazz"],
    //         // "RocknRoll": +datum["Rock n roll"],
    //         // "Alternative": +datum["Alternative"],
    //         // "Latin": +datum["Latino"],
    //         // "Techno_Trance": +datum["Techno, Trance"],
    //         // "Opera": +datum["Opera"]

    //         // "Age": +datum["Age"],
    //         // "Siblings": +datum["Number of siblings"],
    //         // "Gender": datum["Gender"],
    //         // "Education": datum["Education"],
    //         // "Hometown": datum["Village - town"]

    //     };
    // }, function(data) {

        console.log(data);

        var barchart = new BarChart(d3.select("#vis1"), data, 
            function() {

                radarChart.update(data, radarchart.selectedGenre);
            });

        var radarchart = new RadarChart(d3.select("#vis2"), data, "Country");

    });